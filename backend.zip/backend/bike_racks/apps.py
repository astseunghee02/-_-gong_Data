from django.apps import AppConfig


class BikeRacksConfig(AppConfig):
    name = 'bike_racks'
