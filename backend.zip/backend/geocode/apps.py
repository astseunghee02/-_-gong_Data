from django.apps import AppConfig


class GeocodeConfig(AppConfig):
    name = 'geocode'
